#!/bin/sh
exec timeout -k 40s 40s ../dmdscript $@