DMDScript
=========

An implementation of the ECMA 262 (Javascript) programming language
