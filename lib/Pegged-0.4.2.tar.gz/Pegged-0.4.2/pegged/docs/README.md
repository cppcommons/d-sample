# Folder `pegged/docs`

The github Pegged wiki is a git submodule. To get the latest wiki dump, do:

```bash
$ cd <pegged root directory>
$ git submodule init
$ git submodule update
```

This will download the wiki as a bunch of markdown files, for your perusal.
