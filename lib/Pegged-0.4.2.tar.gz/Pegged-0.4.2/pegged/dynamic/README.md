# Folder `pegged/dynamic`

This folder contains the modules for a dynamic grammar generator. The generated grammars
can be modified at runtime. It's not in the docs yet, because it's still buggy.
