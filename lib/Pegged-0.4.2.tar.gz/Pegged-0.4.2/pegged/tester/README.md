# Folder `pegged/tester`

This contains the modules used to test a grammar.
