# Folder `pegged/examples`

These are some grammars (and semantic actions) to show what can be done with Pegged.

